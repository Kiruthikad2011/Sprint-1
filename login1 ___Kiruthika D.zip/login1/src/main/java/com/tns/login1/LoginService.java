package com.tns.login1;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class LoginService {
	
		@Autowired
		private LoginRepository repo;
		
		public void save(Login logy)
		{
			repo.save(logy);
		}
		
		public List<Login> getAllLogin()
		{
			return repo.findAll();
		}
		
		public Login getLoginById(Integer id) 
		{
			return repo.findById(id).orElse(null);
		}
		
		public void deleteLogin(Integer id)
		{
			repo.deleteById(id);
		}

		public void updateLogin(Integer id , Login updatedLogin)
		{
			Login existingLogin = repo.findById(id).orElse(null);
			if (existingLogin != null)
			{
				existingLogin.setPassword(updatedLogin.getPassword());
				
				repo.save(existingLogin);
			}
		}
}
