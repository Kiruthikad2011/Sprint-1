package com.tns.login1;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Login {

		@Id
		@Column(name="loginID")
		private int loginID;
		
		@Column(name="password")
		private String password;
		
		
		public int getLoginID() {
			return loginID;
		}

		public void setloginID(int loginID) {
			this.loginID =loginID;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public Login() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Login(int loginID, String password) {
			super();
			this.loginID = loginID;
			this.password = password;
			
		}

		@Override
		public String toString() {
			return "loginer [loginID=" + loginID + ", password=" + password + "]";
		}

}

